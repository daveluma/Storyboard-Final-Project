package com.example.myapplication

import java.time.LocalDateTime

class Comment internal constructor(var username: String, var comment: String, var createdAt: String) {
}